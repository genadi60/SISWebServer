﻿namespace SIS.HTTP.Enums
{
    public enum HttpRequestMethod
    {
        GET,
        POST,
        PUT,
        DELETE
    }
}
