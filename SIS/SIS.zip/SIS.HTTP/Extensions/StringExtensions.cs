﻿namespace SIS.HTTP.Extensions
{
    public class StringExtensions
    {
        public void Capitalize()
        {
            //TODO:
        }
    }
}
