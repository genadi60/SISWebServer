﻿namespace SIS.HTTP.Cookies.Contracts
{
    public interface IHttpCookie
    {
        string ToString();
    }
}
