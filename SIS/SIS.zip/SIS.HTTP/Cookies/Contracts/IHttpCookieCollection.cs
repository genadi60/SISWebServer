﻿namespace SIS.HTTP.Cookies.Contracts
{
    using System.Collections.Generic;

    public interface IHttpCookieCollection : IEnumerable<HttpCookie>
    {
        void Add(HttpCookie cookie);

        void Add(string key, string value);

        bool ContainsCookie(string key);

        HttpCookie GetCookie(string key);

        void RemoveCookie(HttpCookie cookie);

        Dictionary<string, HttpCookie> GetCookies();

        bool HasCookies();

        string ToString();
    }
}
